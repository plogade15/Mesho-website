const BagsFootwear = [
    {
        heading : "Women Bags",
        data : ["All Women Bags","Handbags","Clutches","Slingbags"]
    },
    {
        heading : "Men Bags",
        data : ["All Men Bags","Men Wallets","Feminine Hygiene"]
    },
    {
        heading : "Men Footwear",
        data : ["Sports Shoes","Casual Shoes","Formal Shoes","Sandals"]
    },
    {
        heading : "Women Footwear",
        data : ["Flats","Bellies","Juttis"]
    },
]


export default BagsFootwear
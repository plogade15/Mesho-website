export default[
    {
        id : "product_1",
        name : "boAt New AirPods Pro",
        desc : "boAt New AirPods Pro with MagSafe Charging Case Visit the Apple Store",
        price : "346",
        rating : "3.5",
        review : "790",
        category : "bluetooth Headset",
        img : "boat_airpods.webp"
    },
    {
        id : "product_2",
        name : "Bluetooth Headset",
        desc : "B11 Wireless Neckband Bluetooth Ear Headset Bluetooth Headset (Blue, In the Ear)",
        price : "120",
        rating : "3.8",
        review : "691",
        category : "bluetooth Headset",
        img : "Bluetooth_Headset_1.webp"
    },
    {
        id : "product_3",
        name : "BLUETOOTH HEADSET WITH MIC",
        desc : "BLUETOOTH HEADSET WITH MIC MULTICOLOR PACK OF 1 PC",
        price : "173",
        rating : "3.7",
        review : "9138",
        category : "bluetooth Headset",
        img : "Bluetooth_Headset_2.webp"
    },
    {
        id : "product_4",
        name : "AIRPODS PRO APPLE Airpod Pro",
        desc : "AIRPODS PRO APPLE Airpod Pro With Wireless Charging Case Active Noise Cancelation Enabled Bluetooth Headset BLACK, True Wireless",
        price : "249",
        rating : "3.9",
        review : "2432",
        category : "bluetooth Headset",
        img : "Bluetooth_Headset_3.webp"
    },
    {
        id : "product_5",
        name : "b11 bluetooth",
        desc : "b11 bluetooth high bass speacial quality neckband",
        price : "120",
        rating : "3.9",
        review : "1500",
        category : "bluetooth Headset",
        img : "Bluetooth_Headset_4.webp"
    },
    {
        id : "product_6",
        name : "BALAJI iPod TWS i12 Earpods",
        desc : "BALAJI iPod TWS i12 Earpods Bluetooth Wireless Earbuds Bluetooth Headset (White, In the Ear)",
        price : "309",
        rating : "3.9",
        review : "249",
        category : "bluetooth Headset",
        img : "Bluetooth_Headset_5.webp"
    },
    {
        id : "product_7",
        name : "boAt F9-5 TWS EarPods",
        desc : "boAt F9-5 TWS EarPods touch control Led earbuds wireless Bluetooth Headset (Black, True Wireless) Airpod",
        price : "454",
        rating : "3.5",
        review : "194",
        category : "bluetooth Headset",
        img : "Bluetooth_Headset_6.webp"
    },
    {
        id : "product_8",
        name : "AIRPODS PRO APPLE Airpod Pro",
        desc : "AIRPODS PRO APPLE Airpod Pro With Wireless Charging Case Active Noise Cancellation Enabled Bluetooth Headset , (BLACK,True Wireless)",
        price : "260",
        rating : "3.9",
        review : "189",
        category : "bluetooth Headset",
        img : "Bluetooth_Headset_7.webp"
    },
    {
        id : "product_9",
        name : "Airpod Pro with Wireless Charging",
        desc : "Airpod Pro with Wireless Charging Case(Blue)",
        price : "469",
        rating : "3.8",
        review : "8",
        category : "bluetooth Headset",
        img : "Bluetooth_Headset_8.webp"
    },
    {
        id : "product_10",
        name : "i12 TWS WIRELESS AIRPODS EARBUD",
        desc : "EARPOD EARPHONE HEADPHONE Bluetooth Earphones Touch Sensor with in Built Mic and High Bass Level Supporting",
        price : "318",
        rating : "3.8",
        review : "2413",
        category : "bluetooth Headset",
        img : "Bluetooth_Headset_9.webp"
    },
    {
        id : "product_11",
        name : "Yogdhara B11 Neckband Sports Bluetooth",
        desc : "Yogdhara B11 Neckband Sports Bluetooth Bluetooth Headset (Blue, In the Ear)",
        price : "219",
        rating : "3.7",
        review : "5443",
        category : "bluetooth Headset",
        img : "Bluetooth_Headset_10.webp"
    },
    {
        id : "product_12",
        name : "NEW AIRPODS PRO With Active Noise Cancellation(black)",
        desc : "NEW AIRPODS PRO With Active Noise Cancellation(black) Bluetooth Bluetooth Headset",
        price : "324",
        rating : "3.9",
        review : "460",
        category : "bluetooth Headset",
        img : "Bluetooth_Headset_11.webp"
    },
    {
        id : "product_13",
        name : "B11 Wireless Bluetooth Headset With Mic",
        desc : "Bluetooth Headset (Blue, In the Ear) B11 Wireless Bluetooth Headset With Mic Bluetooth Headset (Blue, In the Ear) pack of - 1",
        price : "324",
        rating : "3.9",
        review : "460",
        category : "bluetooth Headset",
        img : "Bluetooth_Headset_12.webp"
    },
    {
        id : "product_14",
        name : "Premium Men Gold Brass Chains",
        desc : "Premium Men Gold Brass Chains",
        price : "202",
        rating : "3.9",
        review : "460",
        category : "Men Chains",
        img : "premiumGold_1.webp"
    },
    {
        id : "product_15",
        name : "Bhumi09 Golden Necklace Chain",
        desc : "Bhumi09 Golden Necklace Chain & Bracelet For Boys , Men Stylish",
        price : "212",
        rating : "3.9",
        review : "22",
        category : "Men Chains",
        img : "premiumGold_2.webp"
    },
    {
        id : "product_16",
        name : "Stylish Men's Silver Chain",
        desc : "Stylish Men's Silver Chain",
        price : "300",
        rating : "3.9",
        review : "22",
        category : "Men Chains",
        img : "premiumGold_3.webp"
    },
    {
        id : "product_17",
        name : "Gold",
        desc : "Stylish Men's Silver Chain",
        price : "184",
        rating : "3.9",
        review : "22",
        category : "Men Chains",
        img : "premiumGold_3.webp"
    },
    {
        id : "product_18",
        name : "Men's White Kurta Pyjama Set Combo",
        desc : "Men's White Kurta Pyjama Set Combo in 100% Cotton With Multiple Colour Option And Sizes (Festival,Birthday,Wedding, Ceremony, Casual, Engagement,Party And dandiya nights)",
        price : "369",
        rating : "3.9",
        review : "315",
        category : "Kurtas",
        img : "Kurta_1.webp"
    },
    {
        id : "product_19",
        name : "MEN'S COTTON STRAIGHT KURTA ONLY",
        desc : "Men's White Kurta Pyjama Set Combo in 100% Cotton With Multiple Colour Option And Sizes (Festival,Birthday,Wedding, Ceremony, Casual, Engagement,Party And dandiya nights)",
        price : "265",
        rating : "3.9",
        review : "599",
        category : "Kurtas",
        img : "Kurta_2.webp"
    },
    {
        id : "product_20",
        name : "Mens Straigth ONLY Kurta In 100%",
        desc : "Mens Straigth ONLY Kurta In 100% Cotton With Multiple Colour Option And Sizes (Birthday,Wedding, Ceremony, Casual, Engagement)(only kurta)",
        price : "291",
        rating : "3.9",
        review : "599",
        category : "Kurtas",
        img : "Kurta_4.webp"
    },
    {
        id : "product_21",
        name : "Mobile Chargers",
        desc : "Mobile Chargers",
        price : "145",
        rating : "3.9",
        review : "599",
        category : "Mobile Accessories",
        img : "mobile_acces_1.webp"
    },
    {
        id : "product_22",
        name : "16W 3Amp Super Fast Mobile Charger",
        desc : "16W 3Amp Super Fast Mobile Charger For A9 Charger Original Adapter Universal Mobile Charger | Wall Charger Android Smartphone Travel Charger | Hi Speed Fast Dock Charger With 1 Meter Charging & Sync Micro USB/V8/LG Data Cable ( 3 Amp, 4D, White)",
        price : "352",
        rating : "3.9",
        review : "599",
        category : "Mobile Accessories",
        img : "mobile_acces_2.webp"
    },
    {
        id : "product_23",
        name : "Vivo Y16, Vivo Y 16 Mobile Back Cover, Back Cover",
        desc : "Vivo Y16, Vivo Y 16 Mobile Back Cover, Back Cover",
        price : "352",
        rating : "3.9",
        review : "599",
        category : "Mobile Accessories",
        img : "mobile_acces_3.webp"
    },
    {
        id : "product_24",
        name : "Aagyeyi Alluring Sarees",
        desc : "Aagyeyi Alluring Sarees",
        price : "366",
        rating : "3.9",
        review : "599",
        category : "sarees",
        img : "sarees_1.jpg"
    },
    {
        id : "product_25",
        name : "monika mor",
        desc : "Aagyeyi Alluring Sarees",
        price : "451",
        rating : "3.9",
        review : "599",
        category : "sarees",
        img : "sarees_2.webp"
    },
    {
        id : "product_26",
        name : "Sia Trendy Women's Sarees",
        desc : "Sia Trendy Women's Sarees",
        price : "269",
        rating : "3.9",
        review : "599",
        category : "sarees",
        img : "sarees_3.webp"
    },
    {
        id : "product_26",
        name : "Women's Desinger Georgette Floral",
        desc : "Women's Desinger Georgette Floral Printed Saree with Blouse Piece",
        price : "267",
        rating : "3.9",
        review : "599",
        category : "sarees",
        img : "sarees_4.webp"
    },
    {
        id : "product_27",
        name : "Multi-Functional Boys Casual Business",
        desc : "Multi-Functional Boys Casual Business Men's Luxury Stylish Watch Wrist Watches Daily Use White Dial Analog Watch for Men's & Boy's With King Bracelet King Bracelet Designer Strap",
        price : "267",
        rating : "3.9",
        review : "599",
        category : "watch",
        img : "watch_1.webp"
    },
    {
        id : "product_28",
        name : "Digital LED",
        desc : "Cartoon Character Light-Pink Digital LED Dial Waterproof Cartoon Character Kids Wristband for Boys & Girls Watches Digital LED Dial Waterproof Cartoon Character Kids Wristband for",
        price : "148",
        rating : "3.6",
        review : "599",
        category : "watch",
        img : "watch_2.webp"
    },
]